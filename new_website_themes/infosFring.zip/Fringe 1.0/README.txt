Fringe Theme 1.0: by Greg Rickaby
http://gregrickaby.com/fringe

The Source code, CSS, XHTML and design is released under GPL: http://www.opensource.org/licenses/gpl-license.php

Requirements:
- WordPress 3.1+
- Genesis 1.6+
- Genesis Featured Widget Amplified plug-in (http://wordpress.org/extend/plugins/genesis-featured-widget-amplified/)

Installation:

- Upload /fringe/ to /wp-content/themes/
- Upload Genesis Featured Widget Amplified plug-in to /wp-content/plugins/
- Activate Genesis Featured Widget Amplified plug-in
- Import the Genesis Settings (genesis-theme-settings.json)
- Navigate to Appearance �> Themes and activate �Fringe�
- Customize the Genesis Affiliate Box in functions.php with your own Affiliate link codes
- Change Twitter username in functions.php to your own

Usage & Tips:

- Header image should be 960�80
- Images should be 605�240, no need to set �featured image� �  just upload and insert
- Use the �Insert More Tag� feature of the WYSIWYG editor to shorten your posts on the homepage and create the �Continue Reading� button
- Add the CSS class �last� to the last secondary nav menu item
- If you�re NOT going to use a header image: Appearance �> Header �> Remove Original Image and save

Change Log:

v1.0
- Re-coded CSS from ground up
- Custom Header support
- Custom Background support
- Primary & Secondary navigation support
- Three-column �Featured Stories� widgets header
- Twitter and Facebook integration on homepage stories
- Genesis �Affiliate Box� integration
- Genesis Grid Loop
- Genesis Footer widgets integration
- CSS support for Social Profiles Widget
- Plus, really bold text 

v0.5 
- Initial Release

