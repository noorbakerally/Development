<?php
/** Start the engine **/
require_once(TEMPLATEPATH.'/lib/init.php');

/** Child theme (do not remove) **/
define( 'CHILD_THEME_NAME', 'Fringe Theme' );
define( 'CHILD_THEME_URL', 'http://gregrickaby.com/fringe' );

/** Add support for custom background **/
add_custom_background();

/** Add support for custom header **/
add_theme_support( 'genesis-custom-header', array( 
	'width' => 960, 
	'height' => 80, 
	'textcolor' => 'FFFFFF'
));

/** Add support for 3-column footer widgets **/
add_theme_support( 'genesis-footer-widgets', 3 );

// Add Post Thumbnail Support
set_post_thumbnail_size(605, 240, TRUE);

/** Add new image sizes **/
add_image_size('header-thumbnail', 300, 200, TRUE);
add_image_size('grid-thumbnail', 100, 100, TRUE);

/** Add Support for Post Formats **/
add_theme_support('post-formats', array('aside', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video', 'audio'));
add_theme_support('genesis-post-format-images');
remove_action( 'genesis_before_post_title', 'genesis_do_post_format_image' );
add_action( 'genesis_after_post_title', 'genesis_do_post_format_image' );

/** Unregister other site layouts **/
genesis_unregister_layout('content-sidebar-sidebar');
genesis_unregister_layout('sidebar-sidebar-content');
genesis_unregister_layout('sidebar-content-sidebar');

/** Unregister secondary sidebar **/
unregister_sidebar('sidebar-alt');

/** Move breadcrumbs **/
remove_action('genesis_before_loop', 'genesis_do_breadcrumbs');
add_action('genesis_loop', 'genesis_do_breadcrumbs', 1);

/** Sidebar **/
remove_action('genesis_after_content', 'genesis_get_sidebar');
add_action('genesis_before_content', 'genesis_get_sidebar', 1);

/** Sidebar wrap **/
add_action('genesis_before_sidebar_widget_area', 'child_before_sidebar_widget_area');
add_action('genesis_after_sidebar_widget_area', 'child_after_sidebar_widget_area');

function child_before_sidebar_widget_area() {
	echo '<div class="wrap">';
}

function child_after_sidebar_widget_area() {
	echo '</div>';
}

/** Register widget areas **/
genesis_register_sidebar(array(
	'name'=>'Header 1',
	'id' => 'header-1',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget'  => '</div>',
	'description' => 'This is the first column of the header section.',
	'before_title'=>'<h4 class="widgettitle">','after_title'=>'</h4>'
));
genesis_register_sidebar(array(
	'name'=>'Header 2',
	'id' => 'header-2',
	'before_widget' => '<div id="%1$s" class="widget %2$s">',
	'after_widget'  => '</div>',
	'description' => 'This is the second column of the header section.',
	'before_title'=>'<h4 class="widgettitle">','after_title'=>'</h4>'
));
genesis_register_sidebar(array(
	'name'=>'Header 3',
	'id' => 'header-3',
	'before_widget' => '<div id="%1$s" class="widget %2$s last">',
	'after_widget'  => '</div>',
	'description' => 'This is the third column of the header section.',
	'before_title'=>'<h4 class="widgettitle">','after_title'=>'</h4>'
));

/** Add widgeted header section **/
add_action('genesis_before_content_sidebar_wrap', 'child_include_header_widgets'); 
function child_include_header_widgets() { ?>
<div id="header-widgets" class="header-widgets">
	<div class="wrap">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Header 1') ) : ?>
			<h4><?php _e("Header 1 Widget", 'genesis'); ?></h4>
			<p><?php _e("This is an example of a widgeted area that you can place text to describe a particular product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
		<?php endif; ?> 

		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Header 2') ) : ?>
			<h4><?php _e("Header 2 Widget", 'genesis'); ?></h4>
			<p><?php _e("This is an example of a widgeted area that you can place text to describe a particular product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    <?php endif; ?> 
        
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Header 3') ) : ?>
            <h4><?php _e("Header 3 Widget", 'genesis'); ?></h4>
            <p><?php _e("This is an example of a widgeted area that you can place text to describe a particular product or service. You can also use other WordPress widgets such as recent posts, recent comments, a tag cloud or more.", 'genesis'); ?></p>
	    <?php endif; ?> 
	</div>
</div><!-- end #header-widgets -->
<?php }

/** Add custom text for search button **/
add_filter('genesis_search_button_text', 'custom_search_button_text');
function custom_search_button_text($text) {
    return esc_attr('Search');
}

/** Content wrap **/
add_action('genesis_before_loop', 'child_before_loop');
add_action('genesis_after_loop', 'child_after_loop');

function child_before_loop() {
	echo '<div class="before-loop-wrap">';
}

function child_after_loop() {
	echo '
	<div class="clear"></div>
	</div>';
}

/** Share **/
add_action('genesis_after_post_content', 'sharing_icons');
function sharing_icons() {
if ( is_front_page() ) { ?>
<div id="share">
	<div class="tweetbutton">
		<a href="http://twitter.com/share" class="twitter-share-button"
        	data-count="vertical"
        	data-text="<?php the_title(); ?>"
        	data-url="<?php the_permalink(); ?>"
        	data-via="your-twitter-username">Tweet
        </a>
		<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
	</div>
	<div class="facebutton">
		<div id="fb-root"></div>
		<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
        <fb:like href="<?php the_permalink(); ?>" send="false" layout="box_count" width="80" show_faces="false"></fb:like>
   </div>
</div>
<?php } }

/** Add Genesis Box on Single Posts **/
add_action('genesis_after_post_content', 'include_genesis_box', 25); 
function include_genesis_box() {
    if ( is_single() ) { ?>	
<div id="genesis-box">
	<h3>The Fringe Theme runs on the Genesis Framework</h3>
	<a href="http://www.studiopress.com/themes/genesis"><img class="alignright" src="http://cdn.gregrickaby.com/images/get-genesis.jpg" alt="Genesis Framework" title="Check out the Genesis Framework" /></a>
	<p>Genesis empowers you to quickly and easily build incredible websites with WordPress. Whether you're a novice or advanced developer, Genesis provides the secure and search-engine-optimized foundation that takes WordPress to places you never thought it could go. It's that simple - start using <a href="http://www.studiopress.com/themes/genesis">Genesis</a> now!</p>
	<p>Take advantage of the 6 default layout options, comprehensive SEO settings, rock-solid security, flexible theme options, cool custom widgets, custom design hooks, and a huge selection of child themes ("skins") that make your site look the way you want it to.  With automatic theme updates and world-class support included, Genesis is the smart choice for your WordPress website or blog.</p>
  
	<ul>
		<li>Find out more about the <a href="http://www.studiopress.com/features">framework features</a></li>
		<li>Check out the Genesis demo and the wide variety of <a href="http://www.studiopress.com/themes">child themes</a></li>
		<li>See example designs in the Genesis <a href="http://www.studiopress.com/showcase">design showcase</a></li>
		<li>Become a <a href="http://www.studiopress.com/affiliates">StudioPress Affiliate</a>
	</ul>
</div>
<?php } }

/** Change comment avatar size **/
add_filter('genesis_comment_list_args', 'child_comment_list_args');
function child_comment_list_args($args) {
    $args = array(
			'type' => 'comment',
			'avatar_size' => 48,
			'callback' => 'genesis_comment_callback'
		);
			return $args;
}

/** Customize the footer creds **/
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_footer', 'child_do_footer' );
function child_do_footer() {
	echo do_shortcode( 
			'<div class="gototop"><p>[footer_backtotop]</p></div>' .
			'<div class="creds"><p>[footer_copyright] &#xb7; ' .
			'<a href="' . CHILD_THEME_URL . '" title="' . CHILD_THEME_NAME . '">' . CHILD_THEME_NAME . '</a> on ' .
			'<a href="http://www.studiopress.com/themes/genesis" title="Genesis Framework">Genesis Framework</a></p></div>' );
}