<?php 

/** Setup grid loop **/
remove_action('genesis_after_post_content', 'genesis_post_meta', 10);
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'child_grid_loop_helper' );

/** Set Genesis Grid Loop paramaters **/
function child_grid_loop_helper() {
    if ( function_exists( 'genesis_grid_loop' ) ) {
        genesis_grid_loop( array(
            'features' => 3,
            'feature_image_size' => 0,
            'feature_image_class' => 'post-image',
            'feature_content_limit' => 0,
            'grid_image_size' => 'grid-thumbnail',
            'grid_image_class' => 'alignleft grid-image',
            'grid_content_limit' => 0,
            'more' => __( 'Continue Reading', 'genesis' ),
            'posts_per_page' => 7,
        ) );
    } else {
        genesis_standard_loop();
    }
}

genesis();
