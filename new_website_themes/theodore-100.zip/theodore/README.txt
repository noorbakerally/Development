<strong>THEODORE CHILD THEME</strong>
<a href="http://wpcanada.ca/our-themes/theodore">http://wpcanada.ca/our-themes/theodore</a>

<strong>INSTALL</strong>
1. Upload the Theodore child theme folder via FTP to your wp-content/themes/ directory. (The Genesis parent theme needs to be in the wp-content/themes/ directory as well.)
2. Go to your WordPress dashboard and select Appearance.
3. Activate the Theodore theme.
4. Inside your WordPress dashboard, go to Genesis > Theme Settings and configure them to your liking.

<strong>HOME PAGE USAGE</strong>
<code>home.php</code> == The default homepage uses the <code>home.php</code> template file. This template file contains several widget areas as described in the section called WIDGET AREAS. (further below)
If no widgets are used on this page Theodore will automatically default to a standard blog format to display information on the home page.

<strong>WIDGET AREAS</strong>
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar, Sidebar/Content, Content/Sidebar/Sidebar, Sidebar/Sidebar/Content or Sidebar/Content/Sidebar Site Layout option.
Secondary Sidebar - This is the secondary sidebar if you are using the Content/Sidebar/Sidebar, Sidebar/Sidebar/Content or Sidebar/Content/Sidebar Site Layout option.
Home - This is the main section of the homepage. Use the Genesis Featured Post widget or Genesis Featured Page widget here. Above that widget you can also use either the Genesis Slider
or Genesis Tabs plugin. That is how the demo is setup.
Home Left - This is the left section of the homepage. Use the Genesis Featured Post widget or Genesis Featured Page widget here. The demo uses the Genesis Featured Post widget.
Home Right - This is the right section of the homepage. Use the Genesis Featured Post widget or Genesis Featured Page widget here. The demo uses the Genesis Featured Post widget.
Portfolio - This is the portfolio section for use with the portfolio page template.
Footer #1 - This is the first column of the footer section.
Footer #2 - This is the second column of the footer section.
Footer #3 - This is the third column of the footer section.

<strong>FEATURED IMAGES</strong>
WordPress will create a default thumbnail image for each image you upload and the size can be specified in your dashboard under Settings > Media.

Genesis will create the following image sizes:

&rarr; large 1024x1024
&rarr; medium 300x300
&rarr; thumbnail 150x150

Additionally, Theodore creates the following image sizes:
&rarr; homepage - 140 by 140 == For use with the Genesis Featured Post or Page widget in the Home widget area.
&rarr; mini - 80 by 80 == For use with the Genesis Featured Post or Page widget in the Home Left and Home Right widget areas.
&rarr; portfolio - 202 by 140 == For use with the Portfolio widget with the Portfolio page template.

If you need to regenerate image sizes we highly recommend the Regenerate Thumbnails plugin
http://wordpress.org/extend/plugins/regenerate-thumbnails

<strong>GENESIS SLIDER</strong>
The recommended image dimensions for using the Genesis Slider is 578 by 250.

<strong>PORTFOLIO PAGE</strong>
Theodore comes with a special page template file called <code>page-portfolio.php</code> which is used to display thumbnail images. Here is how to use it:
1. Create a page called "Portfolio" or some such thing. Don't add any content to it. From the drop-down menu select the Portfolio Page template and publish the blank page.
2. Create a category called "Portfolio".
3. Create a series of posts and file them under the Portfolio category. Set a feature image for each post.
4. Add the Genesis Featured Post widget to the Portfolio widget area on the widget screen. Configure. The feature images you selected will automatically appear on the Portfolio page.

<strong>CUSTOM ALERT BOXES</strong>
The custom alert boxes make use of DIV classes. For example, &lt;div class="box-one"&gt;some random text&lt;/div&gt;
There are ten styles to choose from.

<strong>PULLQUOTES</strong>
The pullquotes are added as a class to the existing blockquote which makes for ease of use. There are 2 available pullquotes, right-aligned and left-aligned.
For example, to use a left-aligned pullquote do this ...
&lt;blockquote class="pullquote-left"&gt;This is a left-aligned pullquote.&lt;/blockquote&gt;

and to use a right-aligned pullquote do this ...
&lt;blockquote class="pullquote-right"&gt;This is a right-aligned pullquote.&lt;/blockquote&gt;

<strong>GENESIS BOX</strong>
The Genesis Box is disabled by default. To enable it, open Theodore's <code>functions.php</code> file and uncomment the function. Specifically, look for this ...

<code>/** Add Genesis Box on Single Posts */
//add_action( 'genesis_after_post_content', 'include_genesis_box', 11 );
//function include_genesis_box() {
    //if ( is_single() )
    //require( CHILD_DIR.'/genesis-box.php' );
//}</code>

... and remove all of the //

<strong>POST FORMATS</strong>
To utilize the post format functionality of WordPress and the Theodore theme, you will need to go into Theodore's functions.php file and change this code:

<code>/** Add support for post formats */
// add_theme_support( 'post-formats', array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' ) );
// add_theme_support( 'genesis-post-format-images' );</code>

To this:

<code>/** Add support for post formats */
add_theme_support( 'post-formats', array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' ) );
add_theme_support( 'genesis-post-format-images' );</code>

<strong>CREDIT</strong>
1. Idea for Alert Boxes inspired by Autobahn by DECKERWEB - http://genesisthemes.de/en/genesis-child-themes/autobahn/
2. Icon Set for Bloggers by Rafal Tomal - http://www.studiopress.com/graphics/icon-set-bloggers
3. Post Format Icons by Rafal Tomal - http://www.studiopress.com/graphics/post-format-icons

<strong>RELEASE/DEMO/DOWNLOAD</strong>
1. Theme release page: http://wpcanada.ca/our-themes/theodore/
2. Theme Demo: http://demo.wpcanada.ca/theodore/
3. Theme download page: http://code.google.com/p/theodore-theme/

<strong>BUG REPORTS</strong>
Bug reports can be filed at http://code.google.com/p/theodore-theme/

Enjoy!