<?php
/** Start the engine */
require_once( get_template_directory() . '/lib/init.php' );

/** Localization */
load_child_theme_textdomain( 'theodore', get_stylesheet_directory() . '/lib/languages' );

/** Child theme (do not remove) */
define( 'CHILD_THEME_NAME', 'Theodore Theme' );
define( 'CHILD_THEME_URL', 'http://wpcanada.ca/our-themes/theodore' );

$content_width = apply_filters( 'content_width', 600, 430, 920 );

/** Add new image sizes */
add_image_size( 'homepage', 140, 140, TRUE );
add_image_size( 'mini', 80, 80, TRUE );
add_image_size( 'portfolio', 202, 140, TRUE );

/** Add suport for custom background */
add_custom_background();

/** Add support for custom header */
add_theme_support( 'genesis-custom-header', array( 'width' => 960, 'height' => 180, 'textcolor' => '000000', 'admin_header_callback' => 'theodore_admin_style' ) );

/** Add support for 3-column footer widgets */
add_theme_support( 'genesis-footer-widgets', 3 );

/** Change breadcrumb location */
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
add_action( 'genesis_after_header', 'genesis_do_breadcrumbs' );

/** Breadcrumb display */
add_filter( 'genesis_breadcrumb_args', 'theodore_breadcrumb_args' );
function theodore_breadcrumb_args( $args ) {
	$args['sep'] = ' &raquo; ';
	return $args;
}

/** Add Genesis Box on Single Posts */
add_action( 'genesis_after_post_content', 'include_genesis_box', 11 );
function include_genesis_box() {
    if ( is_single() )
    require( CHILD_DIR.'/genesis-box.php' );
}

/** Add custom body class to the head */
add_filter( 'body_class', 'add_body_class' );
function add_body_class( $classes ) {
   $classes[] = 'theodore';
   return $classes;
}

/** Add post nav to single post pages */
add_action('genesis_before_comments', 'custom_post_nav');
function custom_post_nav(){
    echo '<div class="post-nav">';
    echo '<div class="next-post-nav">';
    echo '<span class="next">';
    echo 'Next Article';
    echo '</span>';
    echo next_post_link('%link', '%title');
    echo '</div>';
    echo '<div class="prev-post-nav">';
    echo '<span class="prev">';
    echo 'Previous Article';
    echo '</span>';
    echo previous_post_link('%link', '%title');
    echo '</div>';
    echo '</div>';
}  

/** Provides markup for the #topnav section */
register_nav_menu('topnav' , __('Top Navigation Menu', 'theodore'));
add_action('genesis_before_header', 'theodore_do_topnav');
function theodore_do_topnav() { ?>
	<div id="topnav">
	<div class="topnav-left">
	<p>theodore for genesis</p>
	</div><!-- end .topnav-left -->
	<div class="topnav-right">
	<?php if ( function_exists('wp_nav_menu') ) { 
	$topnav = wp_nav_menu(array(
	'theme_location' => 'topnav',
	'container' => '',
	'menu_class' => 'topnav superfish',
	'echo' => 0,
	'fallback_cb' => false
	));
	echo $topnav;
	} ?>
	</div><!-- end .topnav-right -->
	</div><!-- end #topnav -->
<?php }

/** Add support for post formats */
add_theme_support( 'post-formats', array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' ) );
add_theme_support( 'genesis-post-format-images' );

/** Remove elements for post formats */
add_action( 'genesis_before_post', 'theodore_remove_elements' );
function theodore_remove_elements() {
	
	if ( ! current_theme_supports( 'post-formats' ) )
		return;

	// Remove if post has format
	if ( get_post_format() ) {
		remove_action( 'genesis_post_title', 'genesis_do_post_title' );
		remove_action( 'genesis_before_post_content', 'genesis_post_info' );
		remove_action( 'genesis_after_post_content', 'genesis_post_meta' );
	}

	// Add back, as post has no format
	else {
		add_action( 'genesis_post_title', 'genesis_do_post_title' );
		add_action( 'genesis_before_post_content', 'genesis_post_info' );
		add_action( 'genesis_after_post_content', 'genesis_post_meta' );
	}

}

/** Register widget areas **/
genesis_register_sidebar( array(
	'id'			=> 'home',
	'name'			=> __( 'Home', 'theodore' ),
	'description'	=> __( 'This is the homepage section.', 'theodore' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-left',
	'name'			=> __( 'Home Left', 'theodore' ),
	'description'	=> __( 'This is the homepage left section.', 'theodore' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'home-right',
	'name'			=> __( 'Home Right', 'theodore' ),
	'description'	=> __( 'This is the homepage right section.', 'theodore' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'portfolio',
	'name'			=> __( 'Portfolio', 'theodore' ),
	'description'	=> __( 'This is the portfolio page template', 'theodore' ),
) );

