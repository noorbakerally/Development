<div id="genesis-box">
    <h3>YourDomain.com runs on the Genesis Framework</h3>
    <a href="AFFILIATE LINK GOES HERE"><img class="alignright" src="<?php echo get_stylesheet_directory_uri() ?>/images/genesis-260x125.jpg" width="260" height="125" alt="Genesis Framework" title="Check out the Genesis Framework" /></a>
    <p>Genesis empowers you to quickly and easily build incredible websites with WordPress. Whether you're a novice or advanced developer, Genesis provides the secure and search-engine-optimized foundation that takes WordPress to places you never thought it could go. It's that simple - start using <a href="AFFILIATE LINK GOES HERE">Genesis</a> now!</p>
    <p>Take advantage of the 6 default layout options, comprehensive SEO settings, rock-solid security, flexible theme options, cool custom widgets, custom design hooks, and a huge selection of child themes ("skins") that make your site look the way you want it to.  With automatic theme updates and world-class support included, Genesis is the smart choice for your WordPress website or blog.</p>
</div>
